"""Reviewed multi-file return from Bamboozle views with explicit resumable imports."""

from __future__ import annotations

from pathlib import Path, PurePosixPath
from typing import Any

from bamboozle.dictionary import Dictionary
from bamboozle.formats import DocumentCodec
from bamboozle.project_views import (
    CONTRACT,
    MAX_FILES,
    MAX_TOTAL_BYTES,
    blob,
    digest,
    document_rules,
    editable_path,
    load_view,
    operation_lock,
    put_blob,
    read_optional,
    relative_name,
    snapshot_view,
    unique_paths,
)
from bamboozle.restoration import _diff
from bamboozle.service import OperationError
from bamboozle.utils import (
    atomic_write,
    exclusive_lock,
    json_bytes,
    parse_json,
    sha256,
    utc_now,
)
from bamboozle.workspace import Workspace


def _deletions(values: list[str] | None) -> list[str]:
    if values is not None and (not isinstance(values, list) or len(values) > MAX_FILES):
        raise ValueError("delete_files must be a bounded list of relative file paths")
    names = [relative_name(name) for name in values or []]
    if len(set(names)) != len(names):
        raise ValueError("Duplicate deletion selection")
    return sorted(names)


def _build(
    workspace: Workspace,
    manifest: dict[str, Any],
    manifest_sha: str,
    mapping: Dictionary,
    view: Workspace,
    directory: Path,
    snapshot: dict[str, bytes],
    delete_files: list[str],
) -> tuple[
    dict[str, Any], dict[str, bytes], list[dict[str, Any]], list[dict[str, str]]
]:
    if (
        CONTRACT not in snapshot
        or sha256(snapshot[CONTRACT]) != manifest["contract_sha256"]
    ):
        raise ValueError("Generated view contract was removed or changed")
    expected: dict[str, str | None] = {}
    outputs: dict[str, bytes] = {}
    actions: list[dict[str, Any]] = []
    conflicts: list[dict[str, str]] = []
    changes: list[dict[str, Any]] = []
    selected_deletions = set(delete_files)
    consumed_deletions: set[str] = set()
    total = 0
    diff_remaining = 262144
    names = sorted(set(manifest["files"]) | (set(snapshot) - {CONTRACT}))
    unique_paths(names)
    if len(names) > MAX_FILES:
        raise ValueError("Import exceeds its file limit")
    for name in names:
        entry = manifest["files"].get(name)
        policy = entry["policy"] if entry else None
        rule = manifest["policy"]["files"].get(name, {})
        if policy == "fixture":
            if name not in snapshot or sha256(snapshot[name]) != entry["view_sha256"]:
                changes.append(
                    {
                        "path": name,
                        "action": "fixture_ignored",
                        "reason": "Fixture edits never replace authoritative source",
                    }
                )
            continue
        try:
            editable_path(workspace, name, manifest["private_paths"], view.root)
        except (ValueError, OSError) as exc:
            conflicts.append({"path": name, "reason": str(exc)})
            continue
        if entry is None:
            if name in manifest["policy"]["files"]:
                conflicts.append(
                    {
                        "path": name,
                        "reason": "Explicitly excluded path cannot be imported",
                    }
                )
                continue
            candidates = [
                prefix
                for prefix in manifest["policy"]["new_files"]
                if prefix == "."
                or PurePosixPath(name).is_relative_to(PurePosixPath(prefix))
            ]
            if not candidates:
                conflicts.append(
                    {
                        "path": name,
                        "reason": "New file is outside the allowed directories",
                    }
                )
                continue
            prefix = max(candidates, key=lambda value: len(PurePosixPath(value).parts))
            rule = manifest["policy"]["new_files"][prefix]
            policy = rule["policy"] if isinstance(rule, dict) else rule
        before = blob(workspace, directory, entry["original_sha256"]) if entry else None
        expected[name] = sha256(before) if before is not None else None
        if name not in snapshot:
            if name not in selected_deletions:
                conflicts.append(
                    {
                        "path": name,
                        "reason": "Missing file requires explicit delete_files selection",
                    }
                )
                continue
            consumed_deletions.add(name)
            decoded = None
        else:
            try:
                text = snapshot[name].decode("utf-8")
                decoded = (
                    DocumentCodec(
                        mapping, document_rules(rule), limit=workspace.max_bytes
                    )
                    .transform(
                        text,
                        "reverse",
                        context=entry.get("document_context", {}) if entry else {},
                    )
                    .text.encode("utf-8")
                    if policy == "translate"
                    else snapshot[name]
                )
            except ValueError as exc:
                conflicts.append({"path": name, "reason": str(exc)})
                continue
            total += len(decoded)
            if len(decoded) > workspace.max_bytes or total > MAX_TOTAL_BYTES:
                raise ValueError("Decoded project exceeds its byte limit")
        if decoded == before:
            continue
        action = {
            "path": name,
            "policy": policy,
            "action": "delete"
            if decoded is None
            else "create"
            if before is None
            else "modify",
            "before_sha256": expected[name],
            "output_sha256": sha256(decoded) if decoded is not None else None,
            "output_bytes": len(decoded) if decoded is not None else 0,
        }
        actions.append(action)
        if decoded is not None:
            outputs[name] = decoded
        difference = _diff(before or b"", decoded or b"")
        size = len(difference["diff"].encode("utf-8"))
        if size > diff_remaining:
            difference = {
                "diff": "",
                "diff_complete": False,
                "diff_reason": "Project diff limit exceeded",
            }
        else:
            diff_remaining -= size
        changes.append({**action, **difference})
    if selected_deletions != consumed_deletions:
        raise ValueError(
            "Deletion selection must name missing editable baseline files only"
        )
    plan = {
        "view_id": manifest["view_id"],
        "manifest_sha256": manifest_sha,
        "view_snapshot": {name: sha256(raw) for name, raw in snapshot.items()},
        "source_snapshot": expected,
        "delete_files": delete_files,
        "actions": actions,
    }
    return plan, outputs, changes, conflicts


def _observations(
    workspace: Workspace,
    manifest: dict[str, Any],
    view: Workspace,
    plan: dict[str, Any],
) -> dict[str, str | None]:
    return {
        name: sha256(raw)
        if (
            raw := read_optional(
                workspace,
                editable_path(workspace, name, manifest["private_paths"], view.root),
            )
        )
        is not None
        else None
        for name in plan["source_snapshot"]
    }


def review_import(
    workspace: Workspace, view_id: str, *, delete_files: list[str] | None = None
) -> dict[str, Any]:
    directory, manifest, manifest_sha, mapping, view = load_view(workspace, view_id)
    if (directory / "import.json").exists():
        raise ValueError(
            "View already has an import; inspect its status or explicitly recover it"
        )
    snapshot = snapshot_view(view)
    plan, _, changes, conflicts = _build(
        workspace,
        manifest,
        manifest_sha,
        mapping,
        view,
        directory,
        snapshot,
        _deletions(delete_files),
    )
    for name, current in _observations(workspace, manifest, view, plan).items():
        if current != plan["source_snapshot"][name]:
            conflicts.append(
                {
                    "path": name,
                    "reason": "Authoritative source changed since export, or new destination already exists",
                }
            )
    return {
        "schema_version": 1,
        "view_id": view_id,
        "status": "conflict" if conflicts else "review",
        "ok": not conflicts,
        "changes": changes,
        "conflicts": conflicts,
        "review_sha256": None if conflicts else sha256(json_bytes(plan)),
        "action_count": len(plan["actions"]),
        "output_saved": False,
    }


def _load_import(
    workspace: Workspace, view_id: str
) -> tuple[Path, dict[str, Any], Workspace, dict[str, Any], dict[str, bytes]]:
    directory, manifest, manifest_sha, mapping, view = load_view(workspace, view_id)
    document = parse_json(workspace.read(directory / "import.json"))
    if (
        not isinstance(document, dict)
        or set(document)
        != {"schema_version", "kind", "created", "plan", "review_sha256"}
        or type(document["schema_version"]) is not int
        or document["schema_version"] != 1
        or document["kind"] != "bamboozle.view-import"
        or not isinstance(document["plan"], dict)
    ):
        raise ValueError("Invalid retained import journal")
    plan = document["plan"]
    if sha256(json_bytes(plan)) != digest(document["review_sha256"]):
        raise ValueError("Retained import digest mismatch")
    if (
        not isinstance(plan.get("view_snapshot"), dict)
        or len(plan["view_snapshot"]) > MAX_FILES + 1
    ):
        raise ValueError("Invalid retained view snapshot")
    snapshot = {}
    total = 0
    for name, fingerprint in plan["view_snapshot"].items():
        relative_name(name)
        raw = blob(workspace, directory, fingerprint)
        total += len(raw)
        if total > MAX_TOTAL_BYTES:
            raise ValueError("Retained view exceeds its byte limit")
        snapshot[name] = raw
    rebuilt, outputs, _, conflicts = _build(
        workspace,
        manifest,
        manifest_sha,
        mapping,
        view,
        directory,
        snapshot,
        _deletions(plan.get("delete_files")),
    )
    if conflicts or json_bytes(rebuilt) != json_bytes(plan):
        raise ValueError("Import no longer matches its retained source/view snapshots")
    for name, data in outputs.items():
        if blob(workspace, directory, sha256(data)) != data:
            raise ValueError(f"Decoded snapshot changed: {name}")
    return directory, manifest, view, document, outputs


def _receipt(plan: dict[str, Any]) -> dict[str, Any]:
    return {
        "kind": "bamboozle.view-import-complete",
        "schema_version": 1,
        "view_id": plan["view_id"],
        "review_sha256": sha256(json_bytes(plan)),
        "manifest_sha256": plan["manifest_sha256"],
        "actions": plan["actions"],
    }


def _states(
    plan: dict[str, Any], observations: dict[str, str | None]
) -> dict[str, str]:
    after = {action["path"]: action["output_sha256"] for action in plan["actions"]}
    return {
        name: "applied"
        if name in after and current == after[name]
        else "unchanged"
        if name not in after and current == plan["source_snapshot"][name]
        else "pending"
        if current == plan["source_snapshot"][name]
        else "conflict"
        for name, current in observations.items()
    }


def view_status(workspace: Workspace, view_id: str) -> dict[str, Any]:
    directory, manifest, _, _, view = load_view(workspace, view_id)
    if not (directory / "import.json").exists():
        review = review_import(workspace, view_id)
        return {
            key: value
            for key, value in {
                **review,
                "status": "conflict" if not review["ok"] else "ready",
            }.items()
            if key != "changes"
        }
    directory, manifest, view, document, _ = _load_import(workspace, view_id)
    states = _states(
        document["plan"], _observations(workspace, manifest, view, document["plan"])
    )
    receipt_path = workspace.resolve(directory / "result.json")
    complete = receipt_path.exists()
    if complete and parse_json(workspace.read(receipt_path)) != _receipt(
        document["plan"]
    ):
        raise ValueError("Invalid completed import receipt")
    observed_view = {name: sha256(raw) for name, raw in snapshot_view(view).items()}
    return {
        "schema_version": 1,
        "view_id": view_id,
        "status": "complete" if complete else "pending",
        "review_sha256": document["review_sha256"],
        "files": states,
        "view_changed": observed_view != document["plan"]["view_snapshot"],
        "receipt_saved": complete,
    }


def apply_import(
    workspace: Workspace,
    view_id: str,
    review_sha256: str,
    *,
    delete_files: list[str] | None = None,
    recover: bool = False,
) -> dict[str, Any]:
    digest(review_sha256)
    with exclusive_lock(operation_lock(workspace)):
        directory, manifest, manifest_sha, mapping, view = load_view(workspace, view_id)
        journal_path = workspace.resolve(directory / "import.json", write=True)
        receipt_path = workspace.resolve(directory / "result.json", write=True)
        if receipt_path.exists():
            raise ValueError(
                "Import already completed; export a fresh view for another development cycle"
            )
        if journal_path.exists() != recover:
            raise ValueError(
                "Existing imports require explicit recovery; recovery requires a retained journal"
            )
        report: dict[str, Any] = {
            "schema_version": 1,
            "view_id": view_id,
            "review_sha256": review_sha256,
            "journal_saved": recover,
            "receipt_saved": False,
            "output_saved": False,
            "applied_files": [],
        }
        plan: dict[str, Any] | None = None
        try:
            if recover:
                if delete_files:
                    raise ValueError("Recovery uses the saved deletion decisions")
                directory, manifest, view, document, outputs = _load_import(
                    workspace, view_id
                )
                plan = document["plan"]
                if document["review_sha256"] != review_sha256:
                    raise ValueError(
                        "Recovery digest does not match the retained import"
                    )
            else:
                snapshot = snapshot_view(view)
                plan, outputs, _, conflicts = _build(
                    workspace,
                    manifest,
                    manifest_sha,
                    mapping,
                    view,
                    directory,
                    snapshot,
                    _deletions(delete_files),
                )
                if conflicts or sha256(json_bytes(plan)) != review_sha256:
                    raise ValueError("Review is stale or contains unresolved conflicts")
                if (
                    _observations(workspace, manifest, view, plan)
                    != plan["source_snapshot"]
                ):
                    raise ValueError("Authoritative source changed after review")
                if not plan["actions"]:
                    return {**report, "status": "no_changes"}
                for raw in [*snapshot.values(), *outputs.values()]:
                    put_blob(workspace, directory, raw)
                document = {
                    "schema_version": 1,
                    "kind": "bamboozle.view-import",
                    "created": utc_now(),
                    "plan": plan,
                    "review_sha256": review_sha256,
                }
                journal = json_bytes(document)
                if len(journal) > workspace.max_bytes:
                    raise ValueError("Import journal exceeds its file limit")
                atomic_write(journal_path, journal)
                report["journal_saved"] = True
            assert plan is not None
            if {name: sha256(raw) for name, raw in snapshot_view(view).items()} != plan[
                "view_snapshot"
            ]:
                raise ValueError(
                    "View changed after review; restore the retained view before recovery"
                )
            if (
                sha256(workspace.read(directory / "manifest.json"))
                != plan["manifest_sha256"]
            ):
                raise ValueError("View manifest changed after review")
            observations = _observations(workspace, manifest, view, plan)
            states = _states(plan, observations)
            if "conflict" in states.values():
                raise ValueError(
                    "Source conflicts with the retained import; inspect view-status"
                )
            for action in plan["actions"]:
                name = action["path"]
                path = editable_path(
                    workspace, name, manifest["private_paths"], view.root
                )
                source_raw = read_optional(workspace, path)
                observed = sha256(source_raw) if source_raw is not None else None
                if observed != action["output_sha256"]:
                    if observed != action["before_sha256"]:
                        raise ValueError(f"Source changed before publication: {name}")
                    if action["action"] == "delete":
                        path.unlink()
                    else:
                        path.parent.mkdir(parents=True, exist_ok=True)
                        path = editable_path(
                            workspace, name, manifest["private_paths"], view.root
                        )
                        atomic_write(
                            path,
                            outputs[name],
                            overwrite=action["before_sha256"] is not None,
                        )
                report["applied_files"].append(name)
                report["output_saved"] = True
            expected = {
                **plan["source_snapshot"],
                **{
                    action["path"]: action["output_sha256"]
                    for action in plan["actions"]
                },
            }
            if _observations(workspace, manifest, view, plan) != expected:
                raise ValueError(
                    "Source changed during import; completion was withheld"
                )
            if {name: sha256(raw) for name, raw in snapshot_view(view).items()} != plan[
                "view_snapshot"
            ]:
                raise ValueError("View changed during import; completion was withheld")
            atomic_write(receipt_path, json_bytes(_receipt(plan)))
            report.update(
                status="recovered" if recover else "applied", receipt_saved=True
            )
            return report
        except (OSError, ValueError, TypeError) as exc:
            report.update(
                status="error",
                error=str(exc),
                journal_saved=journal_path.is_file(),
                receipt_saved=receipt_path.is_file(),
            )
            if journal_path.is_file() and plan is not None:
                try:
                    states = _states(
                        plan, _observations(workspace, manifest, view, plan)
                    )
                    report["files"] = states
                    report["applied_files"] = [
                        name for name, state in states.items() if state == "applied"
                    ]
                    report["output_saved"] = bool(report["applied_files"])
                except (OSError, ValueError):
                    report["observation_incomplete"] = True
            raise OperationError(str(exc), report) from exc
